/*
脚本功能：解锁流利说·阅读会员、解锁阅读权限、解锁音频权限等
脚本作者：R·E
脚本发布：https://t.me/Functional_Store_Hub

更新时间：2022.07.27
支持版本：商店版本 
下载地址：https://apps.apple.com/app/id1435478035

使用声明：⚠️⚠️⚠️此脚本仅供学习与交流,禁止转载与贩卖,需在24小时内从设备中删除！⚠️⚠️⚠️
*/

var _0x5c3696=$response['body'];var _0x3d6a05=$request['url'];if(_0x3d6a05['indexOf']('/api/v2/member/subscription')!=-0x1){var _0xab86ec={};_0xab86ec['expiredAt']=0x70db6800;_0xab86ec['remainDays']=0x3e7;_0xab86ec['active']=!![];_0xab86ec['startedAt']=0x61ec29ff;var _0x57dba3=_0xab86ec;_0x5c3696=JSON['stringify'](_0x57dba3);var _0x41be63={};_0x41be63['body']=_0x5c3696;$done(_0x41be63);}else if(_0x3d6a05['indexOf']('/api/v2/user_goods_subscriptions/overall')!=-0x1){var _0x172290={};_0x172290['startedAt']=0x61e2ef80;_0x172290['category']=0x4;_0x172290['status']=0x2;_0x172290['expiredAt']=0x61ec29ff;_0x172290['goodsTitle']='member';_0x172290['remainDays']=0x3e7;_0x172290['goodsUid']='XnV1EW';_0x172290['firstStartedAt']=0x70db6800;var _0x21883a={};_0x21883a['items']=[_0x172290];var _0x57dba3=_0x21883a;_0x5c3696=JSON['stringify'](_0x57dba3);var _0x387301={};_0x387301['body']=_0x5c3696;$done(_0x387301);}$done();