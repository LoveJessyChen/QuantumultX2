<div align="center">
<h1 align="center">Geo Location Checker
<br>本地Geo检查器<h1>
<p align="center" color="#6a737d"><p>
<h3 align="center">支持QuantumultX、优化中文和英文<h3>
<h4 align="center">Version 1.3<h4>
<br>
</div>
<b>使用方式：</b>

编辑配置，[general]下替换掉 <b>geo_location_checker=</b> 所在行代码 <b>以下版本二选一</b>

台湾地区旗帜替换为🇨🇳版

```
geo_location_checker=http://ip-api.com/json/?lang=zh-CN, https://raw.githubusercontent.com/I-am-R-E/Functional-Store-Hub/Master/GeoLocationChecker/QuantumultX/IP-API.js
```
  
台湾地区旗帜显示为🇹🇼版
```
geo_location_checker=http://ip-api.com/json/?lang=zh-CN, https://raw.githubusercontent.com/I-am-R-E/Functional-Store-Hub/Master/GeoLocationChecker/QuantumultX/IP-API-TaiwanFlag.js
```

🎉 你可以在这里找到使用方法和注意事项: [Functional Store Hub 频道](https://t.me/Functional_Store_Hub)
 
😀 如果你想反馈问题,你可以直接在Github上提交issues或者加入[Functional Store Hub Discussion 群组](https://t.me/Functional_Store_Hub_Discussion)找到我
