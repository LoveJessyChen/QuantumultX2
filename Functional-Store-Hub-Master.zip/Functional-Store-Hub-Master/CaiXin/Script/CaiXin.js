/*
脚本功能：解锁财新阅读、音频限制
脚本作者：R·E
支持版本：商店最新 7.9.3
下载地址：https://apps.apple.com/us/app/%E8%B4%A2%E6%96%B0-%E6%B5%81%E8%A8%80%E6%97%A0%E5%A4%84%E4%B8%8D%E5%9C%A8-%E7%9C%9F%E7%9B%B8%E5%B0%B1%E8%AF%BB%E8%B4%A2%E6%96%B0/id356023612
更新时间：2022.07.19
问题反馈：https://t.me/Functional_Store_Hub
使用声明：⚠️⚠️⚠️此脚本仅供学习与交流，禁止转载与贩卖！⚠️⚠️⚠️
*/
var _0x177f40=$request['headers'];_0x177f40['User-Agent']='Mozilla/5.0\x20(iPhone;\x20CPU\x20iPhone\x20OS\x2015_4_1\x20like\x20Mac\x20OS\x20X)\x20AppleWebKit/605.1.15\x20(KHTML,\x20like\x20Gecko)\x20Mobile/15E148\x20CaixinV5/7.9.3\x20deviceType/1';const _0x4726b2=$request['url']['replace'](/uid=(\d+|)/g,'uid=8401805')['replace'](/code=(\w+|)/g,'code=F78278D6A77823B98CB44BCC62E38558')['replace'](/device=(\w+|)/g,'device=699440d159f8b18216b678d3261c91afa3a8a444')['replace'](/deviceType=(\d+|)/g,'deviceType=1');if($request['url']['indexOf']('validateAudioAuth')!=-0x1){_0x177f40['appinfo']='75SU0e5TW70SSqRtJ/F6dN60qhTR/VmZTj9JQB4m3Uwq7sM2Mqb98OoOmr%2BJGjxMer45axESuqqrtjbo%2Bm5AYRzduI5eFvoYMcmS35ifWwfGXmPy6G3ZfPagiTWEn%2BM%2BPAUiArgEuqyBgwc3OMuvj5jYaliJKDZ6LuUieXHIFRTu/7a7DCFvIxZFQkeQjA4dDHXMWIqoT1Vx7k7vkaRp7rVdzSUSO5SaMvFbYOY1VWBz8n8d4JbNklAPNWS7sjK3umhjWq70j8MbjSCItzxFw88h49NsDs8fH47fALaZvQR63FgsF/Ab0HP46n/5Q0sDF2C9WTk/r6tIh/Rg%2BMTQZVSYimZ6XctG8QciSjRKgNs/xQUwYap6FnT2XT6QNtNzdutTVUUH43crJm51OyLzYC66vdKsBdZQAT5SRD9TLgA41tQIv/ixuxeSREnoZVBoVFTe2PIQ2IdmbE12Hjz8F38ZIgJbXNKzysRQwi7RRhrc9fGcRRcUQYFW0nCxMl/SkT42OtjQklw%3D';}$done({'url':_0x4726b2,'headers':_0x177f40});
