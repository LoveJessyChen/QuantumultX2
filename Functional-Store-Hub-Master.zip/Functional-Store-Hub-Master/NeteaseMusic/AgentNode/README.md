<div align="center">
<h1 align="center">Functional Store Hub<h1>
<p align="center" color="#6a737d"><p>
<h3 align="center">解锁网易云灰色和VIP音乐节点<h3>
<br>
</div>
<div align="center">

| 软件名称 | 节点数量 | 更新时间 | 资源链接 |
| :----: | :----: | :----: | :----: |
| Surge | 12 | 2022.07.16 | [Surge.list](https://raw.githubusercontent.com/I-am-R-E/Functional-Store-Hub/Master/NeteaseMusic/AgentNode/Surge.list) |
| QuantumultX | 12 | 2022.07.16 | [QuantumultX.snippet](https://raw.githubusercontent.com/I-am-R-E/Functional-Store-Hub/Master/NeteaseMusic/AgentNode/QuantumultX.snippet) |
| Loon | 12 | 2022.07.16 | [Loon.list](https://raw.githubusercontent.com/I-am-R-E/Functional-Store-Hub/Master/NeteaseMusic/AgentNode/Loon.list) |
| Stash | 12 | 2022.07.16 | [Stash.yaml](https://raw.githubusercontent.com/I-am-R-E/Functional-Store-Hub/Master/NeteaseMusic/AgentNode/Stash.yaml) |
| ShadowRocket | 12 | 2022.07.16 | [Shadowrocket.list](https://raw.githubusercontent.com/I-am-R-E/Functional-Store-Hub/Master/NeteaseMusic/AgentNode/Shadowrocket.list) |

</div>
<div align="center">
简略使用方法:分流指向节点<br><br>详细使用方法:https://t.me/Functional_Store_Hub/18
</div>
