/*
脚本功能：解锁Nicegram会员
脚本作者：R·E
支持版本：商店最新 1.0.7
更新时间：2022.07.24
问题反馈：https://t.me/Functional_Store_Hub
使用声明：⚠️⚠️⚠️此脚本仅供学习与交流，禁止转载与贩卖！⚠️⚠️⚠️
*/
const _0x81265e=typeof $task!='undefined';if(_0x81265e){console['log']('\x0aR·E\x20Nicegram\x20Script\x20Log:\x0aNicegram\x20Premium已解锁😎');const _0x4463fe={};_0x4463fe['Content-Type']='application/json';const _0x523423={};_0x523423['status']='HTTP/1.1\x20200\x20OK';_0x523423['headers']=_0x4463fe;_0x523423['body']='{\x22data\x22:\x20{\x22premiumAccess\x22:\x20true}}';$done(_0x523423);}else{console['log']('\x0aR·E\x20Nicegram\x20Script\x20Log:\x0aNicegram\x20Premium已解锁😎');const _0x55d468={};_0x55d468['Content-Type']='application/json';const _0x39aa7d={};_0x39aa7d['status']='200';_0x39aa7d['headers']=_0x55d468;_0x39aa7d['body']='{\x22data\x22:\x20{\x22premiumAccess\x22:\x20true}}';$done(_0x39aa7d);}
